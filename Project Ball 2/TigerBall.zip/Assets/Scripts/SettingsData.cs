using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;

public class SettingsData : MonoBehaviour
{
    [HideInInspector]public bool soundVolume = true;
    [HideInInspector] public bool musicVolume = true;
}
